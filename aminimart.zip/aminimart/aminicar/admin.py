from django.contrib import admin
from aminicar.models import Account

admin.site.register(Account)